Programming Assignment 1 -- Yuliang Xiao & Yuanwu He

Instruction for runnning the program

1. Open the MATLAB and add the PROGRAMS folder and its subfolder to the path
2. Run the PA1_FullFile.m to oeprate the program.
3. The result is displayed in the command window.